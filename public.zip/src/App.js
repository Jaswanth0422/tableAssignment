import './App.css';
//import Users from './components/userscomponent';
//import Table from './components/classTable';
import TableContainer from './components/tableContainer';

function App() {
  return (
    <div className="App">
      <TableContainer/>
      {/* <Users/> */}
      {/* <Table/> */}
    </div>
  );
}

export default App;
