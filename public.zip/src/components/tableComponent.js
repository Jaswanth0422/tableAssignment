import React from 'react';
import '../App.css';


const Table = (props) => {
   
    const TableHeader=()=>{
        return(
            <tr>
                <th>Ticker</th>
                <th>Price</th>
                <th>AssetClass</th>
            </tr>
        )
    }
    return (
        <>
        <table className="tflex">
        <tbody>
            <TableHeader/>
            {props.rowdata.map((data,i)=>(
            <tr key={i} className={data.assetClass==="Macro"?"tRowWhite":data.assetClass==="Equities"?"tRowBlue":"tRowGreen"}>
                <td>{data.ticker}</td>
                <td className={data.price>0?"tRowPriceBlue":"tRowPriceRed"}>{data.price}</td>
                <td>{data.assetClass}</td>
            </tr>
        ))}
        </tbody>
        </table>
        </>
    )
}

export default Table;